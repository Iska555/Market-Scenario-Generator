"""HTTP contracts and validation."""
